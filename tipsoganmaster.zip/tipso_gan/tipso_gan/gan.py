import tensorflow as tf
from tensorflow.keras import layers, models

def build_generator(latent_dim=100, output_shape=(32,32,3)):
    inputs = layers.Input(shape=(latent_dim,))
    x = layers.Dense(4*4*512)(inputs)
    x = layers.Reshape((4,4,512))(x)
    # upsample blocks with residual skip
    for filters in [256, 128, 64]:
        x0 = x
        x = layers.Conv2DTranspose(filters, 4, strides=2, padding="same")(x)
        x = layers.LeakyReLU(0.2)(x)
        x = layers.Conv2D(filters, 3, padding="same", dilation_rate=2)(x)
        x = layers.LeakyReLU(0.2)(x)
        # project skip if needed
        if x0.shape[-1] != x.shape[-1]:
            x0 = layers.Conv2D(x.shape[-1], 1, padding="same")(x0)
        x = layers.Add()([x, x0])  # residual
    x = layers.Conv2D(output_shape[-1], 3, padding="same", activation="tanh")(x)
    return models.Model(inputs, x, name="Generator")

def build_discriminator(input_shape=(32,32,3)):
    inputs = layers.Input(shape=input_shape)
    x = layers.Conv2D(64, 4, strides=2, padding="same")(inputs)
    x = layers.LeakyReLU(0.2)(x)
    x = layers.Conv2D(128, 4, strides=2, padding="same")(x)
    x = layers.LeakyReLU(0.2)(x)
    x = layers.Conv2D(256, 4, strides=2, padding="same")(x)
    x = layers.LeakyReLU(0.2)(x)
    feat = layers.Flatten(name="flatten_features")(x)   # features for reconstruction
    logits = layers.Dense(1)(feat)
    # label smoothing handled in loss
    return models.Model(inputs, [logits, feat], name="Discriminator")