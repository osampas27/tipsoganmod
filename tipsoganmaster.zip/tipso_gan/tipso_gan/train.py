import numpy as np
import tensorflow as tf
from tensorflow.keras import optimizers
from .config import TIPSOConfig
from .gan import build_generator, build_discriminator
from .deepred import build_deepred
from .losses import focal_loss, reconstruction_loss, adversarial_losses, DynamicLossCombiner
from .pso import AdaptivePSO

cfg = TIPSOConfig()

class TIPSOTrainer:
    def __init__(self, input_shape=(32,32,3)):
        self.latent_dim = 100
        self.gen = build_generator(self.latent_dim, input_shape)
        self.disc = build_discriminator(input_shape)
        self.dee = build_deepred(input_shape=input_shape, lambda_decay=cfg.lambda_decay)

        self.opt_g = optimizers.Adam(cfg.lr, beta_1=0.5, beta_2=0.999)
        self.opt_d = optimizers.Adam(cfg.lr, beta_1=0.5, beta_2=0.999)

        self.loss_combiner = DynamicLossCombiner(cfg.alpha, cfg.beta, cfg.gamma)

    def _sample_latent(self, n):
        return tf.random.normal((n, self.latent_dim))

    def pretrain_psogan(self, X_normal, epochs=5, batch_size=128):
        # Standard GAN pretraining on normal traffic only
        dataset = tf.data.Dataset.from_tensor_slices(X_normal).shuffle(10000).batch(batch_size)
        for ep in range(epochs):
            for real in dataset:
                z = self._sample_latent(tf.shape(real)[0])
                with tf.GradientTape() as td, tf.GradientTape() as tg:
                    fake = self.gen(z, training=True)
                    d_logits_real, feat_real = self.disc(real, training=True)
                    d_logits_fake, feat_fake = self.disc(fake, training=True)
                    d_loss, g_adv = adversarial_losses(d_logits_real, d_logits_fake, label_smoothing=True)
                    # simple recon to encourage fidelity
                    recon = tf.reduce_mean(tf.abs(real - fake))
                    g_loss = self.loss_combiner.combine(g_adv, recon, 0.0)

                grads_d = td.gradient(d_loss, self.disc.trainable_variables)
                grads_g = tg.gradient(g_loss, self.gen.trainable_variables)
                self.opt_d.apply_gradients(zip(grads_d, self.disc.trainable_variables))
                self.opt_g.apply_gradients(zip(grads_g, self.gen.trainable_variables))

    def pso_initialize(self, X_batch):
        # Lightweight PSO to pick init vector w* that minimizes early combined loss
        # over a frozen snapshot of net weights (here, we tune α,β,γ and a small bias vector to seed generator).
        dim = 3 + self.latent_dim  # [alpha,beta,gamma] + seed vec
        def objective(vec):
            a,b,g = vec[0], vec[1], vec[2]
            s = abs(a)+abs(b)+abs(g)+1e-6
            a,b,g = abs(a)/s, abs(b)/s, abs(g)/s
            seed = vec[3:].reshape((1,-1))
            z = np.repeat(seed, repeats=X_batch.shape[0], axis=0)
            z = z + np.random.randn(*z.shape)*0.05
            z = z.astype("float32")
            fake = self.gen(z, training=False)
            d_real, feat_real = self.disc(X_batch, training=False)
            d_fake, feat_fake = self.disc(fake, training=False)

            d_loss, g_adv = adversarial_losses(d_real, d_fake, label_smoothing=True)
            recon = tf.reduce_mean(tf.abs(X_batch - fake))
            comb = a*g_adv + b*recon + g*0.0
            return float(comb.numpy())

        pso = AdaptivePSO(
            swarm_size=cfg.swarm_size, w_min=cfg.w_min, w_max=cfg.w_max,
            c1=cfg.c1, c2=cfg.c2, sigma_share=cfg.sigma_share, alpha_share=cfg.alpha_share,
            beta_randn=cfg.beta_randn, k_sigmoid=cfg.k_sigmoid, f_threshold=cfg.f_threshold,
            delta_t=cfg.delta_t, stagnation_T=cfg.stagnation_T
        )
        gbest, fbest = pso.optimize(dim=dim, objective=objective, max_iter=200)
        a,b,g = gbest[0], gbest[1], gbest[2]
        s = abs(a)+abs(b)+abs(g)+1e-6
        self.loss_combiner = DynamicLossCombiner(abs(a)/s, abs(b)/s, abs(g)/s)

    def train_tipso(self, X_normal, X_val, y_val, epochs=10, batch_size=128):
        # Transfer: init discriminator with DeePred weights
        # Build DeePred classifier first on (normal + known attacks) in a real setup.
        # Here for demo, we just pretrain on synthetic labels y_val (binary) a bit.
        self.dee.compile(optimizer="adam", loss="sparse_categorical_crossentropy", metrics=["acc"])
        self.dee.fit(X_val, y_val, epochs=2, batch_size=batch_size, verbose=0)
        # Transfer backbone to discriminator top dense if compatible (demo: skip complex mapping).

        dataset = tf.data.Dataset.from_tensor_slices(X_normal).shuffle(10000).batch(batch_size)
        # PSO initialize loss weights on a batch
        for real in dataset.take(1):
            self.pso_initialize(real.numpy())
            break

        best_val_acc = 0.0
        drops = 0

        for ep in range(epochs):
            for real in dataset:
                z = self._sample_latent(tf.shape(real)[0])
                with tf.GradientTape() as td, tf.GradientTape() as tg:
                    fake = self.gen(z, training=True)
                    d_logits_real, feat_real = self.disc(real, training=True)
                    d_logits_fake, feat_fake = self.disc(fake, training=True)

                    # Discriminator: adversarial + focal for minority class (label 1), with pseudo-labels
                    d_loss_adv, g_adv = adversarial_losses(d_logits_real, d_logits_fake, label_smoothing=True)
                    # create labels for focal: real->0, fake->1
                    y_real = tf.zeros_like(d_logits_real)
                    y_fake = tf.ones_like(d_logits_fake)
                    fl = focal_loss(tf.concat([y_real,y_fake],0), tf.concat([d_logits_real,d_logits_fake],0),
                                    alpha=cfg.focal_alpha, gamma=cfg.focal_gamma)
                    d_loss = d_loss_adv + fl

                    # Generator loss includes reconstruction
                    recon = reconstruction_loss(real, feat_real, self.gen)
                    g_loss = self.loss_combiner.combine(g_adv, recon, 0.0)

                grads_d = td.gradient(d_loss, self.disc.trainable_variables)
                grads_g = tg.gradient(g_loss, self.gen.trainable_variables)
                self.opt_d.apply_gradients(zip(grads_d, self.disc.trainable_variables))
                self.opt_g.apply_gradients(zip(grads_g, self.gen.trainable_variables))

            # simple validation using DeePred as proxy detector on val set
            preds = self.dee.predict(X_val, verbose=0)
            acc = np.mean(np.argmax(preds, axis=1).reshape(-1,1) == y_val.reshape(-1,1))
            print(f"[TIPSO] epoch {ep+1}/{epochs} val-acc={acc:.4f}  (best={best_val_acc:.4f})")
            if acc > best_val_acc:
                best_val_acc = acc
            else:
                drops += 1
                if drops >= cfg.patience_drop or best_val_acc >= cfg.val_acc_threshold:
                    print("[TIPSO] Early stop by validation gate.")
                    break