import tensorflow as tf
from tensorflow.keras import layers

class TemporalDecayMHSA(layers.Layer):
    def __init__(self, num_heads=4, key_dim=32, lambda_decay=0.5, **kwargs):
        super().__init__(**kwargs)
        self.mha = layers.MultiHeadAttention(num_heads=num_heads, key_dim=key_dim)
        self.lambda_decay = lambda_decay

    def build(self, input_shape):
        # Expect shape (B, T, C)
        super().build(input_shape)

    def call(self, x, training=False):
        # x: (B, T, C). Build a decay mask Γ where Γ_{t,i} = exp(-λ |t - i|)
        B, T, C = tf.unstack(tf.shape(x))
        idx = tf.range(T, dtype=tf.float32)
        t = tf.reshape(idx, (T, 1))
        i = tf.reshape(idx, (1, T))
        dist = tf.abs(t - i)  # (T, T)
        Gamma = tf.exp(-self.lambda_decay * dist)  # (T, T)

        # Keras MHA supports attention_mask (1 for keep, 0 for mask). We need weights reweighting.
        # Use attention_scores function via _compute_attention to inject Gamma. Simpler: scale queries.
        # Trick: apply Gamma post-attention via residual weighting.
        attn = self.mha(x, x, x, training=training)  # (B, T, C)
        # Approximate temporal bias by a 1D conv with kernel derived from Gamma's first row (decay w.r.t. distance)
        kernel = tf.reshape(Gamma[0], (T, 1, 1))
        kernel = kernel / (tf.reduce_sum(kernel) + 1e-8)
        kernel = tf.transpose(kernel, [1, 0, 2])  # (1, T, 1)
        attn_ = tf.nn.conv1d(attn, kernel, stride=1, padding="SAME")
        return attn_