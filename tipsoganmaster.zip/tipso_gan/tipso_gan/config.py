from dataclasses import dataclass

@dataclass
class TIPSOConfig:
    # Data
    input_shape = (32, 32, 3)     # consistent with paper figures
    num_classes = 2               # normal vs malicious (binary)
    train_val_test = (0.6, 0.2, 0.2)

    # PSO
    swarm_size = 100
    iter_max = 1000
    w_min = 0.4
    w_max = 0.9
    c1 = 2.05
    c2 = 2.05
    stagnation_T = 25
    sigma_share = 0.5
    alpha_share = 1.0
    beta_randn = 1e-3
    k_sigmoid = 6.0
    f_threshold = 1e-4
    delta_t = 10

    # Focal loss
    focal_alpha = 1.0
    focal_gamma = 2.5

    # Dynamic loss weights (α + β + γ = 1), PSO will fine-tune
    alpha = 0.5  # adversarial
    beta = 0.5   # reconstruction
    gamma = 0.0  # stability placeholder

    # Training
    batch_size = 128
    epochs_pretrain = 5   # keep light for demo
    epochs_tipso = 10
    lr = 2e-4
    val_acc_threshold = 0.9995   # 99.95%
    patience_drop = 3            # n drops before break

    # MHSA decay
    lambda_decay = 0.5