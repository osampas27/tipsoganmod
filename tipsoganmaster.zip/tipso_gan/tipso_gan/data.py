import numpy as np
from sklearn.model_selection import train_test_split

def synthetic_tabular_to_image(n_normal=5000, n_mal=2000, img_shape=(32,32,3), seed=42):
    rng = np.random.default_rng(seed)
    # fabricate 10D features then map to 32x32x3 image by tiling and noise
    def makeX(n, center):
        X = rng.normal(center, 1.0, size=(n, 10))
        img = X @ rng.normal(0, 0.2, size=(10, img_shape[0]*img_shape[1]*img_shape[2]))
        img = img.reshape((n,)+img_shape)
        img = np.tanh(img)  # [-1,1]
        return img

    Xn = makeX(n_normal, 0.0)
    Xm = makeX(n_mal, 2.0)
    yn = np.zeros((n_normal,1), dtype=np.int32)
    ym = np.ones((n_mal,1), dtype=np.int32)
    X = np.concatenate([Xn, Xm], axis=0)
    y = np.concatenate([yn, ym], axis=0)
    return X, y

def split_train_val_test(X, y, splits=(0.6,0.2,0.2), seed=42):
    X_train, X_tmp, y_train, y_tmp = train_test_split(X, y, train_size=splits[0], random_state=seed, stratify=y)
    val_ratio = splits[1] / (splits[1] + splits[2])
    X_val, X_test, y_val, y_test = train_test_split(X_tmp, y_tmp, train_size=val_ratio, random_state=seed, stratify=y_tmp)
    return (X_train, y_train), (X_val, y_val), (X_test, y_test)

def get_normal_only(X, y):
    mask = (y.flatten() == 0)
    return X[mask], y[mask]