import tensorflow as tf
from tensorflow.keras import layers, models
from .mhsa import TemporalDecayMHSA

def build_deepred(input_shape=(32,32,3), num_classes=2, lambda_decay=0.5):
    inputs = layers.Input(shape=input_shape)

    x = layers.Conv2D(128, 3, strides=2, padding="same")(inputs)   # 16x16x128
    x = layers.LeakyReLU(0.2)(x)
    x = layers.Conv2D(256, 3, strides=2, padding="same")(x)        # 8x8x256
    x = layers.LeakyReLU(0.2)(x)
    x = layers.Conv2D(512, 3, strides=2, padding="same")(x)        # 4x4x512
    x = layers.LeakyReLU(0.2)(x)

    # flatten to sequence T x C (treat spatial as sequence)
    B = tf.shape(x)[0]
    T = (input_shape[0]//8)*(input_shape[1]//8)
    C = 512
    x_seq = layers.Reshape((T, C))(x)

    x_seq = TemporalDecayMHSA(num_heads=4, key_dim=64, lambda_decay=lambda_decay)(x_seq)
    x = layers.Reshape((input_shape[0]//8, input_shape[1]//8, C))(x_seq)

    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dense(256, activation="relu")(x)
    outputs = layers.Dense(num_classes, activation="softmax")(x)

    model = models.Model(inputs, outputs, name="DeePred")
    return model