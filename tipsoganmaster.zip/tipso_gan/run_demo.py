from tipso_gan.train import TIPSOTrainer, cfg
from tipso_gan.data import synthetic_tabular_to_image, split_train_val_test, get_normal_only
import numpy as np

def main():
    X, y = synthetic_tabular_to_image(n_normal=2000, n_mal=800, img_shape=(32,32,3))
    (Xtr, ytr), (Xv, yv), (Xte, yte) = split_train_val_test(X, y, cfg.train_val_test)

    # Stage-1: PSOGAN on normal-only
    Xn, _ = get_normal_only(Xtr, ytr)
    trainer = TIPSOTrainer(input_shape=(32,32,3))
    print("[Stage-1] Pretraining PSOGAN on normal-only...")
    trainer.pretrain_psogan(Xn, epochs=cfg.epochs_pretrain, batch_size=cfg.batch_size)

    # Stage-2: TIPSO-GAN with transfer + PSO-initialized dynamic loss
    print("[Stage-2] Training TIPSO-GAN...")
    trainer.train_tipso(Xn, Xv, yv, epochs=cfg.epochs_tipso, batch_size=cfg.batch_size)
    print("Done. You can now adapt data loaders and hyperparameters for your datasets.")

if __name__ == "__main__":
    main()