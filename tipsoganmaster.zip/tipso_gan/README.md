# TIPSO-GAN (TensorFlow 2.15)

A reference implementation scaffold of **TIPSO-GAN** based on the uploaded NDSS'26 paper.
This code mirrors the paper's core ideas:

- Two-stage training (PSOGAN pretraining on normal; TIPSO-GAN with transfer to detect unknowns)
- PSO-assisted initialization with **adaptive sigmoidal inertia** and **diversity preservation**
- Discriminator enhanced via **DeePred** (CNN + MHSA with temporal decay)
- **Dynamic loss** combining adversarial, reconstruction (L1), and stability terms
- **Focal loss** in the discriminator to address class imbalance
- Early stopping / validation gating as described

> This is a compact, readable scaffold to run locally and extend. It includes sensible defaults, comments,
and TODOs to wire in your datasets (e.g., CIC-IDS2018, CIC-DDoS2019, CICAPT-IIoT2024).

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate  # on Windows: .venv\Scripts\activate
pip install -r requirements.txt

# run a small synthetic demo
python run_demo.py
```

The `run_demo.py` script fabricates toy "normal" vs "malicious" tabular data and shows the full training flow
without heavy datasets. Replace `tipso_gan/data.py` with your real loaders.

## Project layout

- `tipso_gan/mhsa.py` — Multi-Head Self Attention with **temporal decay** factor λ
- `tipso_gan/deepred.py` — **DeePred** CNN + MHSA binary classifier
- `tipso_gan/gan.py` — DCGAN-like **Generator**/**Discriminator**, reconstruction head, label smoothing
- `tipso_gan/losses.py` — Focal loss, reconstruction loss, dynamic loss wrapper
- `tipso_gan/pso.py` — **PSO** with adaptive sigmoidal inertia & diversity-preserving strategies
- `tipso_gan/train.py` — Two-stage pipeline (Algorithm 1 & 2), early-stop/validation gating
- `tipso_gan/data.py` — Synthetic demo data + placeholders for real datasets
- `run_demo.py` — End-to-end demo script

## Notes

- TensorFlow 2.15 is pinned to mirror the paper's stack.
- The PSO step is engineered to initialize generator weights (and α,β,γ) by evaluating a shallow fitness
  on mini-batches before standard Adam training. It won't be as heavy as full-blown PSO over all weights
  but captures the paper's intent.
- Swap to real datasets and tune hyperparameters in `tipso_gan/config.py`.